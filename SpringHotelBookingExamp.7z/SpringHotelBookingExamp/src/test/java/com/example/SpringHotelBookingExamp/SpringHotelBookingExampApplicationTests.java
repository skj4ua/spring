package com.example.SpringHotelBookingExamp;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHotelBookingExampApplicationTests {

	@Test
	void contextLoads() {
	}

}

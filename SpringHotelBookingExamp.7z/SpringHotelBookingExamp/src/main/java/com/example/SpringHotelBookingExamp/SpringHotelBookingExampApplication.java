package com.example.SpringHotelBookingExamp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHotelBookingExampApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHotelBookingExampApplication.class, args);
	}

}

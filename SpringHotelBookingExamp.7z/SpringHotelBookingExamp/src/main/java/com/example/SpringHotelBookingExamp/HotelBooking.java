package com.example.SpringHotelBookingExamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class HotelBooking {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private long id;
	private String hotelname;
	private double pricepernight;
	private int nbOfNights;
	
	public HotelBooking() {
	}
	
	public HotelBooking(String hotelname,double pricepernight,int nbOfNights) {
		this.hotelname=hotelname;
		this.pricepernight=pricepernight;
		this.nbOfNights=nbOfNights;
				
	}

	public String getHotelname() {
		return hotelname;
	}

	public double getPricepernight() {
		return pricepernight;
	}

	public int getNbOfNights() {
		return nbOfNights;
	}
	
	public double getTotalPrice() {
		return pricepernight*nbOfNights;
	}
	  public long getId() {
	        return id;
	    }
	
}
